package com.springboot.imgur.responsedata;

public @interface Email {

}
