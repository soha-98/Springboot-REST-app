package com.springboot.imgur.responsedata;

public @interface Size {

	int max();

	int min();

}
