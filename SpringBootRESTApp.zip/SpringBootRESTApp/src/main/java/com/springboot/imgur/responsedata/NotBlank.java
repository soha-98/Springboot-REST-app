package com.springboot.imgur.responsedata;

public @interface NotBlank {

}
