package com.springboot.imgur.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
